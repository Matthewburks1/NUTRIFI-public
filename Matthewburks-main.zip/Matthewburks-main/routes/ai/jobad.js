
const express = require('express');
const openai = require('../middlewares/openai');

let app = express.Router()

// input tokens: 150
// input characters: 600
// output tokens: 50
// output characters: 200

app.post('/jobad', async (req, res, next) => {
	let { content, currentPrompt, Height, Weight, Gender, Age, Activitylevel} = req.body
  
	let prompt = "create a detailed diet plan based on the following details:\n'${content}'\n\n"
	let inputRaw = ""


	if(currentPrompt === "Weight loss calculator"){
		prompt = `Create a detailed diet plan to lose weight based on the folowing details:\n'${content}'\n\n`
	   `Height: 5'10\nWeight: 180\nGender: Male, Female, Other\nAge: 30\nActivitylevel: High, Medium, Low\n:JOB AD:\n###`
	  inputRaw = `Height: ${Height}\nWeight: ${Weight}\nGender: ${Gender}\nAge: ${Age}\nActivitylevel: ${Activitylevel}\n\nJOB AD:\n`
	  prompt += inputRaw
	}
  
	
  
	const gptResponse = await openai.complete({
		engine: 'text-davinci-003',
		prompt,
		maxTokens: 200,
		temperature: 0.5,
		topP: 1,
		frequencyPenalty: 0.2,
		presencePenalty: 0,
		bestOf: 1,
		n: 1,
		user: req.user._id,
		stream: false,
		stop: ["###", "<|endoftext|>","JOB AD","TEXT" ],
	});
  
	let output = `${gptResponse.data.choices[0].text}`

	// remove the first character from output
	output = output.substring(1, output.length)

	// If the output string ends with one or more hashtags, remove all of them
	if (output.endsWith('"')) {
		output = output.substring(0, output.length - 1)
	}

	// If the output string ends with one or more hashtags, remove all of them
	if (output.endsWith('"')) {
		output = output.substring(0, output.length - 1)
	}

	// remove a single new line at the end of output if there is one
	if (output.endsWith('\n')) {
		output = output.substring(0, output.length - 1)
	}

	req.locals.input = prompt
	req.locals.inputRaw = inputRaw
	req.locals.output = output

	next()
	
  })

  module.exports = app