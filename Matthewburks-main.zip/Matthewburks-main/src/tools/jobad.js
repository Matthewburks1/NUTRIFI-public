import {
	ClipboardListIcon,
} from '@heroicons/react/solid'


const obj = {

	title: "Weight Loss Calculator",
	desc: "Transform your body with precision and efficiency using our AI-powered Weight Loss Calculator.",
	category: "Weight Loss Calculator",
	Icon: ClipboardListIcon,
	// tags: [],
	permissions: ['user'],

	to: "/ai/jobad",
	api: "/ai/jobad",
	
	fromColor: "blue-600",
	toColor: "yellow-500",

	output: {
		title: "Weight Loss Calculator",
		desc: "Just ask a question and watch as the answers come to life before your eyes",
		// Icon: RefreshIcon,
		// color: "",
	},

	prompts: [{
		title:"Weight Loss Calculator",
		desc: "",
		// n: 1,
		prompts: [
			{ 
				title: "Height", 
				attr: "height",  
				value: "", 
				placeholder: "5'10", 
				label: "",
				// type: "textarea",
				maxLength: 40,
				// max: 100,
				min: 2,
				required: true,
				error: "",
				example: "5'10",
			},
			{ 
				title: "Weight", 
				attr: "weight",  
				value: "", 
				placeholder: "180", 
				label: "",
				// type: "textarea",
				maxLength: 20,
				// max: 100,
				min: 3,
				required: true,
				error: "",
				example: "180",
			},
			{ 
				title: "Gender", 
				attr: "Gender",  
				value: "", 
				placeholder: "Male, Female, Other", 
				label: "",
				// type: "textarea",
				// maxLength: 600,
				// max: 100,
				// min: 1,
				// required: true,
				error: "",
				example: "",
			},
			{ 
				title: "Age", 
				attr: "age",  
				value: "", 
				placeholder: "30", 
				label: "",
				// type: "textarea",
				maxLength: 40,
				// max: 100,
				// min: 1,
				// required: true,
				error: "",
				example: "",
			},
			{ 
				title: "Activity level", 
				attr: "activity level",  
				value: "", 
				placeholder: "High, Medium, Low", 
				label: "",
				// type: "textarea",
				maxLength: 40,
				// max: 100,
				// min: 1,
				// required: true,
				error: "",
				example: "",
			},
		],
		example: {
output: `

Breakfast:
-  2 eggs, scrambled 
- 1 cup of oatmeal 
- An apple with nut butter. 
			
Lunch:
- A salad made with leafy greens, grilled chicken, avocado slices, tomatoes, and a light vinaigrette dressing. 

			
Dinner:
Whole wheat pasta with a vegetable-based sauce.`,
			// outputs: [],
			// Icon: RefreshIcon,
			// color: "",
		}
	},]
}

export default obj

