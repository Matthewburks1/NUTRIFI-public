import nutrition from './nutrition';
import NUTRIFI from './NUTRIFI';
import jobad from './jobad';
const TOOLS = [
	nutrition,
	NUTRIFI,
	jobad,
]

export default TOOLS
