import {
	ViewListIcon,
} from '@heroicons/react/solid'


const obj = {

	title: "NUTRIFI",
	desc: "Get personalized guidance for any sport or training question with our sports coach - the ultimate fitness companion for all your athletic pursuits."	,
	category: "NUTRIFI",
	Icon: ViewListIcon,
	// tags: [],
	permissions: ['user'],
	
	fromColor: "gray-500",
	toColor: "gray-500",

	to: "/ai/NUTRIFI",
	api: "/ai/NUTRIFI",

	output: {
		title: "NUTRIFI",
		desc: "Just ask a question and watch as the answers come to life before your eyes",
		Icon: false,
		color: "blue",
	},

	prompts: [{
		title:"NUTRIFI",
		desc: "Maximize your potential with our AI sports coach - the ultimate training partner for athletes of all levels.",
		// n: 1,
		prompts: [{ 
				title: "Content", 
				attr: "content",  
				value: "", 
				placeholder: "Give me a plan to get stronger on the bench press ", 
				label: "",
				type: "textarea",
				maxLength: 600,
				// max: 100,
				min: 3,
				required: true,
				error: "",
				example: "Give me a plan to get stronger on the bench press ",
			},
		],
		example: {
			output: 
			
			`-Warm up with 5 minutes of light cardio 
			-3 sets of 8 reps of incline dumbbell press
			-3 sets of 10 reps of flat dumbbell press
			-3 sets of 12 reps decline dumbbell press 
			-2 sets of 15 reps bent over barbell rows`

,
			// outputs: [
			// 	"The sun is very old, over 4.5 billion years",
			// 	"At 10,000 degrees, sun is also very hot",
			// 	"Gasses called coronal mass ejections erupt from the sun",
			// ],
			// Icon: RefreshIcon,
			color: "blue",
		}
	}]
		
}

export default obj

