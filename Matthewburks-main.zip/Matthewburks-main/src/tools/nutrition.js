import {
	ViewListIcon,
} from '@heroicons/react/solid'


const obj = {

	title: "Nutrition",
	desc: "Fuel your body with expert nutrition advice for a healthier you."	,
	category: "Nutrition",
	Icon: ViewListIcon,
	// tags: [],
	permissions: ['user'],
	
	fromColor: "gray-500",
	toColor: "gray-500",

	to: "/ai/nutrition",
	api: "/ai/nutrition",

	output: {
		title: "Nutrition",
		desc: "Just ask a question and watch as the answers come to life before your eyes",
		Icon: false,
		color: "blue",
	},

	prompts: [{
		title:"Nutrition",
		desc: "Analyze your nutrition goals and give feedback on how to go about achieving them.",
		// n: 1,
		prompts: [{ 
				title: "Content", 
				attr: "content",  
				value: "", 
				placeholder: "How should I go about losing wieght?", 
				label: "",
				type: "textarea",
				maxLength: 600,
				// max: 100,
				min: 3,
				required: true,
				error: "",
				example: "how do I lose weight ",
			},
		],
		example: {
			output: "Create a caloric deficit based on the results from an online BMR calculator based on that Information go into a 100-500 caloric deficit from that BMR number. ",
			// outputs: [
			// 	"The sun is very old, over 4.5 billion years",
			// 	"At 10,000 degrees, sun is also very hot",
			// 	"Gasses called coronal mass ejections erupt from the sun",
			// ],
			// Icon: RefreshIcon,
			color: "blue",
		}
	}]
		
}

export default obj

